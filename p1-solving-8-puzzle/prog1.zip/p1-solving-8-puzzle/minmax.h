#ifndef MINMAX_H
#define MINMAX_H

#include "tree.h"

#include <limits>
#include <string>
using namespace std;

void minmax(Node* root);

#endif