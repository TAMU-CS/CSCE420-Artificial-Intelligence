Instructions on running the program (C++):
1. make sure you are in the project directory 
2. run "make"
3. run "./prover"
4. type option number and hit enter
