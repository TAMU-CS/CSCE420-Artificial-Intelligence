#ifndef PARSER_H
#define PARSER_H

using namespace std;

#include <vector>
#include <string>

class Parser{
  public:
    static vector<string> parse_terms(string);
};

#endif
